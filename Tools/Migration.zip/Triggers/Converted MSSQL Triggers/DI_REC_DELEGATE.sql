/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[DI_REC_DELEGATE]    Script Date: 02/23/2016 14:46:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Remarks:
-- Added CURSOR
-- Added Insert statement
--Rev Log
--See above
--added by CCR DC_CLASS_RNO should have a value before inserting into table. 
CREATE TRIGGER [dbo].[DI_REC_DELEGATE] 
	ON [dbo].[DI_REC] INSTEAD OF INSERT -- BEFORE INSERT
AS
BEGIN--(1)
	DECLARE @current_dc_class_rno BIGINT 
	DECLARE @current_type BIGINT 
	DECLARE @current_act_id BIGINT 
	DECLARE @current_rec_id VARCHAR(32)
	DECLARE @current_dis_rno BIGINT 
	DECLARE @current_seqno BIGINT 
	DECLARE @current_act_rec DATETIME 
	DECLARE @current_act_ack DATETIME 
	DECLARE @current_act_closed DATETIME 
	DECLARE @current_plan_close DATETIME 
	DECLARE @current_deleted BIGINT 
	DECLARE @current_issue BIGINT 
	DECLARE @current_dr_cond_code VARCHAR(255)
	DECLARE @current_dr_priority BIGINT 
	DECLARE @current_dr_user_ack VARCHAR(32)
	DECLARE @current_dr_user_close VARCHAR(32)
	DECLARE @current_workdays BIGINT 
	DECLARE @current_dr_act_finished BIGINT 
	DECLARE @current_act_rec_datetime DATETIME 
	DECLARE @NEW_PLAN_CLOSE DATETIME


	/* --========================================================================================================
 	Remarks: changed by Cathy using Select Statement

	DECLARE FOR_EACH_ROW_CURSOR CURSOR LOCAL FOR 
	SELECT
			 dc_class_rno,
			 type,
			 act_id,
			 rec_id,
			 dis_rno,
			 seqno,
			 act_rec,
			 act_ack,
			 act_closed,
			 plan_close,
			 deleted,
			 issue,
			 dr_cond_code,
			 dr_priority,
			 dr_user_ack,
			 dr_user_close,
			 workdays,
			 dr_act_finished,
			 act_rec_datetime 
	FROM  inserted 
	
	OPEN FOR_EACH_ROW_CURSOR
	FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO
		@current_dc_class_rno, 
		@current_type, 
		@current_act_id, 
		@current_rec_id,
		@current_dis_rno, 
		@current_seqno, 
		@current_act_rec,
		@current_act_ack, 
		@current_act_closed, 
		@current_plan_close,
		@current_deleted, 
		@current_issue, 
		@current_dr_cond_code,
		@current_dr_priority, 
		@current_dr_user_ack,
		@current_dr_user_close,
		@current_workdays, 
		@current_dr_act_finished, 
		@current_act_rec_datetime
	
	WHILE (@@FETCH_STATUS <> -1)
	BEGIN--(2)

        --========================================================================================================*/

	--Remarks:
	-- Added by Cathy 
	SELECT @current_dc_class_rno = Inserted.DC_CLASS_RNO FROM Inserted
	SELECT @current_type = Inserted.[TYPE] FROM Inserted
	SELECT @current_act_id = Inserted.ACT_ID FROM Inserted
	SELECT @current_rec_id = Inserted.REC_ID  FROM Inserted
	SELECT @current_dis_rno = Inserted.DIS_RNO FROM Inserted
	SELECT @current_seqno = Inserted.SEQNO FROM Inserted
	SELECT @current_act_rec = Inserted.ACT_REC FROM Inserted
	SELECT @current_act_ack = Inserted.ACT_ACK FROM Inserted
	SELECT @current_act_closed = Inserted.ACT_CLOSED FROM Inserted
	SELECT @current_plan_close = Inserted.PLAN_CLOSE FROM Inserted
	SELECT @current_deleted = Inserted.DELETED FROM Inserted
	SELECT @current_issue = Inserted.ISSUE FROM Inserted
	SELECT @current_dr_cond_code = Inserted.DR_COND_CODE FROM Inserted
	SELECT @current_dr_priority = Inserted.DR_PRIORITY FROM Inserted
	SELECT @current_dr_user_ack = Inserted.DR_USER_ACK FROM Inserted
	SELECT @current_dr_user_close = Inserted.DR_USER_CLOSE FROM Inserted
	SELECT @current_workdays = Inserted.WORKDAYS FROM Inserted
	SELECT @current_dr_act_finished = Inserted.DR_ACT_FINISHED FROM Inserted
	SELECT @current_act_rec_datetime = Inserted.ACT_REC_DATETIME FROM Inserted
	
	IF (SELECT COUNT(*) FROM inserted) > 0 AND (SELECT COUNT(*) FROM deleted) = 0
		BEGIN--(3)
			SELECT DISTINCT @NEW_PLAN_CLOSE  =  plan_close
			FROM  di_rec_plan dr 
			WHERE	 dis_rno  = @current_dis_rno
			 AND	rec_id  = @current_rec_id
			 AND	Act_ID  = @current_act_id



			-- Added by Cathy to show value using Trace
			--IF @current_dc_class_rno = NULL --DC_CLASS_RNO should have a value before inserting into table.  
			--BEGIN --(4)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_dc_class_rno as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_type as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_act_id as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + @current_rec_id
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_dis_rno as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_seqno as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_act_rec as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_act_ack as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_act_closed as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_deleted as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_issue as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + @current_dr_cond_code
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_dr_priority as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + @current_dr_user_ack
			--print '<-------------------------------boing rec delegate boing -----------------' + @current_dr_user_close
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_workdays as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_dr_act_finished as varchar)
			--print '<-------------------------------boing rec delegate boing -----------------' + cast(@current_act_rec_datetime as varchar)


			INSERT INTO dbo.DI_REC(
				 dc_class_rno,
				 type,
				 act_id,
				 rec_id,
				 dis_rno,
				 seqno,
				 act_rec,
				 act_ack,
				 act_closed,
				 plan_close,
				 deleted,
				 issue,
				 dr_cond_code,
				 dr_priority,
				 dr_user_ack,
				 dr_user_close,
				 workdays,
				 dr_act_finished,
				 act_rec_datetime 
			)
			VALUES ( 
				@current_dc_class_rno, 
				@current_type, 
				@current_act_id, 
				@current_rec_id,
				@current_dis_rno, 
				@current_seqno, 
				@current_act_rec,
				@current_act_ack, 
				@current_act_closed, 
				@NEW_PLAN_CLOSE, --@current_plan_close,
				@current_deleted, 
				@current_issue, 
				@current_dr_cond_code,
				@current_dr_priority, 
				@current_dr_user_ack,
				@current_dr_user_close,
				@current_workdays, 
				@current_dr_act_finished, 
				@current_act_rec_datetime	
			)
			--END--(4)
		END--(3)

/*--========================================================================================================

Remarks: Commented by Cathy
	FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO
			@current_dc_class_rno, 
			@current_type, 
			@current_act_id, 
			@current_rec_id,
			@current_dis_rno, 
			@current_seqno, 
			@current_act_rec,
			@current_act_ack, 
			@current_act_closed, 
			@current_plan_close,
			@current_deleted, 
			@current_issue, 
			@current_dr_cond_code,
			@current_dr_priority, 
			@current_dr_user_ack,
			@current_dr_user_close,
			@current_workdays, 
			@current_dr_act_finished, 
			@current_act_rec_datetime
END--(2)

	CLOSE FOR_EACH_ROW_CURSOR
	DEALLOCATE FOR_EACH_ROW_CURSOR

--========================================================================================================*/

END--(1)
--========================================================================================================
--BASELINE (PL/SQL): 
--DROP TRIGGER F00A6TC00_PROARC.DI_REC_DELEGATE;
--CREATE OR REPLACE TRIGGER F00A6TC00_PROARC."DI_REC_DELEGATE"
--   BEFORE INSERT
--   ON "F00A6TC00_PROARC".DI_REC    REFERENCING NEW AS NEW OLD AS OLD
--   FOR EACH ROW
--DECLARE
--BEGIN
--    SELECT distinct plan_close
--      INTO :NEW.PLAN_CLOSE
--   FROM di_rec_plan dr
--     WHERE dis_rno = :new.dis_rno and
--      rec_id=:new.rec_id and
--     Act_ID= :new.Act_ID;
--EXCEPTION
--   WHEN OTHERS
--   THEN
--      raise_application_error (-20000, SUBSTR (SQLERRM, 1, 200));
--END;
--/
GO


