/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_DOCUMENT]    Script Date: 02/23/2016 15:28:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Remarks:
--Added TWO CURSORS
--Added Insert and Delete statements

--Rev Log
--FLOAT(126) to Float
--@counter FLOAT to INTEGER

CREATE TRIGGER [dbo].[TRG_DOCUMENT] 
    ON [dbo].[DOCUMENT] INSTEAD OF INSERT, UPDATE --BEFORE INSERT OR UPDATE
AS
BEGIN--(1)

	DECLARE @fetchstatus INTEGER, @fetchdeletestatus INTEGER

    DECLARE @sRevStat VARCHAR(20) 
    DECLARE @counter INTEGER --FLOAT

	DECLARE @DOC_RNO      INTEGER
	DECLARE @DB_RNO       INTEGER
	DECLARE @DOC_ID       VARCHAR(60)
	DECLARE @TITLE        VARCHAR(255)
	DECLARE @FORMAT_ID    VARCHAR(10)
	DECLARE @CREATED     DATETIME
	DECLARE @CREATED_BY   VARCHAR(32)
	DECLARE @MODIFIED_M  DATETIME
	DECLARE @MODIFIED_BY  VARCHAR(32)
	DECLARE @MODIFIED_C  DATETIME
	DECLARE @MODIFIED_P  DATETIME
	DECLARE @VOIDED      DATETIME
	DECLARE @FLAG_DESC    INTEGER
	DECLARE @PACK_RNO     INTEGER
	DECLARE @CHAIN        INTEGER
	DECLARE @PLANHOURS    FLOAT--(126)
	DECLARE @WEIGHT       INTEGER
	DECLARE @LOCKED      DATETIME
	DECLARE @LOCK_BY      VARCHAR(32)
	DECLARE @HOLDS        INTEGER
	DECLARE @REVISION     VARCHAR(20)
	DECLARE @VERSION      VARCHAR(10)
	DECLARE @STATUS       VARCHAR(20)
	DECLARE @REV_ID       INTEGER
	DECLARE @VER_ID       INTEGER
	DECLARE @STATDATE    DATETIME
	DECLARE @MASK_RNO     INTEGER
	DECLARE @FILE_SEQNO   INTEGER
	DECLARE @FILE_COUNT   INTEGER

 	DECLARE @OLD_DOC_RNO INTEGER

/* ==============================

--Remarks: Commented by Cathy
DECLARE FOR_EACH_ROW_CURSOR CURSOR LOCAL FOR 
    SELECT 
		DOC_RNO,
		DB_RNO,
		DOC_ID,
		TITLE,
		FORMAT_ID,
		CREATED,
		CREATED_BY,
		MODIFIED_M,
		MODIFIED_BY,
		MODIFIED_C,
		MODIFIED_P,
		VOIDED,
		FLAG_DESC,
		PACK_RNO,
		CHAIN,
		PLANHOURS,
		WEIGHT,
		LOCKED,
		LOCK_BY,
		HOLDS,
		REVISION,
		VERSION,
		STATUS,
		REV_ID,
		VER_ID,
		STATDATE,
		MASK_RNO,
		FILE_SEQNO,
		FILE_COUNT
    FROM inserted 
    
    DECLARE FOR_EACH_ROW_DELETE_CURSOR CURSOR LOCAL FOR 
    SELECT DOC_RNO FROM deleted 
    
    OPEN FOR_EACH_ROW_CURSOR 
            FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO
				  @DOC_RNO
				, @DB_RNO
				, @DOC_ID
				, @TITLE
				, @FORMAT_ID
				, @CREATED
				, @CREATED_BY
				, @MODIFIED_M
				, @MODIFIED_BY
				, @MODIFIED_C
				, @MODIFIED_P
				, @VOIDED
				, @FLAG_DESC
				, @PACK_RNO
				, @CHAIN
				, @PLANHOURS
				, @WEIGHT
				, @LOCKED
				, @LOCK_BY
				, @HOLDS
				, @REVISION
				, @VERSION
				, @STATUS
				, @REV_ID
				, @VER_ID
				, @STATDATE
				, @MASK_RNO
				, @FILE_SEQNO
				, @FILE_COUNT
	Select @fetchstatus = @@FETCH_STATUS

    OPEN FOR_EACH_ROW_DELETE_CURSOR 
            FETCH NEXT FROM FOR_EACH_ROW_DELETE_CURSOR INTO @OLD_DOC_RNO
	Select @fetchdeletestatus = @@FETCH_STATUS

	WHILE (@fetchstatus <> -1 AND @fetchdeletestatus <> -1)
    BEGIN--(2)



=================================*/

	SELECT @DOC_RNO = Inserted.DOC_RNO FROM Inserted
	SELECT @DOC_ID = Inserted.DOC_ID FROM Inserted
	SELECT @DB_RNO = Inserted.DB_RNO FROM Inserted
	SELECT @TITLE = Inserted.TITLE FROM Inserted
	SELECT @FORMAT_ID = Inserted.FORMAT_ID FROM Inserted
	SELECT @CREATED = Inserted.CREATED FROM Inserted
	SELECT @CREATED_BY = Inserted.CREATED_BY FROM Inserted
	SELECT @MODIFIED_M = Inserted.MODIFIED_M FROM Inserted
	SELECT @MODIFIED_BY = Inserted.MODIFIED_BY FROM Inserted
	SELECT @MODIFIED_C = Inserted.MODIFIED_C FROM Inserted
	SELECT @MODIFIED_P = Inserted.MODIFIED_P FROM Inserted
	SELECT @VOIDED = Inserted.VOIDED FROM Inserted
	SELECT @FLAG_DESC = Inserted.FLAG_DESC FROM Inserted
	SELECT @PACK_RNO = Inserted.PACK_RNO FROM Inserted
	SELECT @CHAIN = Inserted.CHAIN FROM Inserted
	SELECT @PLANHOURS = Inserted.PLANHOURS FROM Inserted
	SELECT @WEIGHT = Inserted.WEIGHT FROM Inserted
	SELECT @LOCKED = Inserted.LOCKED FROM Inserted
	SELECT @LOCK_BY = Inserted.LOCK_BY FROM Inserted
	SELECT @HOLDS = Inserted.HOLDS FROM Inserted
	SELECT @REVISION = Inserted.REVISION FROM Inserted
	SELECT @VERSION = Inserted.VERSION FROM Inserted
	SELECT @STATUS = Inserted.STATUS FROM Inserted
	SELECT @REV_ID = Inserted.REV_ID FROM Inserted
	SELECT @VER_ID = Inserted.VER_ID FROM Inserted
	SELECT @STATDATE = Inserted.STATDATE FROM Inserted
	SELECT @MASK_RNO = Inserted.MASK_RNO FROM Inserted
	SELECT @FILE_SEQNO = Inserted.FILE_SEQNO FROM Inserted
	SELECT @FILE_COUNT = Inserted.FILE_COUNT FROM Inserted
	
	SELECT @OLD_DOC_RNO = deleted.DOC_RNO FROM deleted
	

        IF @DB_RNO = 2 
        BEGIN--(3)
            SELECT @counter  =  COUNT(STATUS)
            FROM  REVISION 
            WHERE     DOC_RNO  = @DOC_RNO
             AND    REV_ID  = @REV_ID
             AND    VER_ID  = @VER_ID
            
            IF @counter > 0 
            BEGIN--(4)
                SELECT @sRevStat  =  STATUS
                FROM  REVISION 
                WHERE     DOC_RNO  = @DOC_RNO
                 AND    REV_ID  = @REV_ID
                 AND    VER_ID  = @VER_ID
                
                UPDATE  DX_2   
                SET    REVSTAT = @sRevStat 
                WHERE  DOC_RNO  = @DOC_RNO 
                
            END--(4)
       
        END--(3)
       
        IF (SELECT COUNT(*) FROM inserted) > 0 AND (SELECT COUNT(*) FROM deleted) > 0
			UPDATE DOCUMENT
			SET
				DB_RNO = @DB_RNO,
				DOC_ID = @DOC_ID,
				TITLE = @TITLE,
				FORMAT_ID = @FORMAT_ID,
				CREATED = @CREATED,
				CREATED_BY = @CREATED_BY,
				MODIFIED_M = @MODIFIED_M,
				MODIFIED_BY = @MODIFIED_BY,
				MODIFIED_C = @MODIFIED_C,
				MODIFIED_P = @MODIFIED_P,
				VOIDED = @VOIDED,
				FLAG_DESC = @FLAG_DESC,
				PACK_RNO = @PACK_RNO,
				CHAIN = @CHAIN,
				PLANHOURS = @PLANHOURS,
				WEIGHT = @WEIGHT,
				LOCKED = @LOCKED,
				LOCK_BY = @LOCK_BY,
				HOLDS = @HOLDS,
				REVISION = @REVISION,
				VERSION = @VERSION,
				STATUS = @STATUS,
				REV_ID = @REV_ID,
				VER_ID = @VER_ID,
				STATDATE = @STATDATE,
				MASK_RNO = @MASK_RNO,
				FILE_SEQNO = @FILE_SEQNO,
				FILE_COUNT = @FILE_COUNT
			WHERE DOC_RNO = @OLD_DOC_RNO

        IF (SELECT COUNT(*) FROM inserted) > 0 AND (SELECT COUNT(*) FROM deleted) = 0
            INSERT INTO DOCUMENT (
				DOC_RNO,
				DB_RNO,
				DOC_ID,
				TITLE,
				FORMAT_ID,
				CREATED,
				CREATED_BY,
				MODIFIED_M,
				MODIFIED_BY,
				MODIFIED_C,
				MODIFIED_P,
				VOIDED,
				FLAG_DESC,
				PACK_RNO,
				CHAIN,
				PLANHOURS,
				WEIGHT,
				LOCKED,
				LOCK_BY,
				HOLDS,
				REVISION,
				VERSION,
				STATUS,
				REV_ID,
				VER_ID,
				STATDATE,
				MASK_RNO,
				FILE_SEQNO,
				FILE_COUNT )
             VALUES (
				@DOC_RNO,
				@DB_RNO,
				@DOC_ID,
				@TITLE,
				@FORMAT_ID,
				@CREATED,
				@CREATED_BY,
				@MODIFIED_M,
				@MODIFIED_BY,
				@MODIFIED_C,
				@MODIFIED_P,
				@VOIDED,
				@FLAG_DESC,
				@PACK_RNO,
				@CHAIN,
				@PLANHOURS,
				@WEIGHT,
				@LOCKED,
				@LOCK_BY,
				@HOLDS,
				@REVISION,
				@VERSION,
				@STATUS,
				@REV_ID,
				@VER_ID,
				@STATDATE,
				@MASK_RNO,
				@FILE_SEQNO,
				@FILE_COUNT )

END--(1)

/*====================================================
--Remarks: Commented by Cathy

FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO
				  @DOC_RNO
				, @DB_RNO
				, @DOC_ID
				, @TITLE
				, @FORMAT_ID
				, @CREATED
				, @CREATED_BY
				, @MODIFIED_M
				, @MODIFIED_BY
				, @MODIFIED_C
				, @MODIFIED_P
				, @VOIDED
				, @FLAG_DESC
				, @PACK_RNO
				, @CHAIN
				, @PLANHOURS
				, @WEIGHT
				, @LOCKED
				, @LOCK_BY
				, @HOLDS
				, @REVISION
				, @VERSION
				, @STATUS
				, @REV_ID
				, @VER_ID
				, @STATDATE
				, @MASK_RNO
				, @FILE_SEQNO
				, @FILE_COUNT

            FETCH NEXT FROM FOR_EACH_ROW_DELETE_CURSOR INTO @OLD_DOC_RNO

    END--(2)

    CLOSE FOR_EACH_ROW_CURSOR
    DEALLOCATE FOR_EACH_ROW_CURSOR
    CLOSE FOR_EACH_ROW_DELETE_CURSOR
    DEALLOCATE FOR_EACH_ROW_DELETE_CURSOR


====================================================*/
GO


