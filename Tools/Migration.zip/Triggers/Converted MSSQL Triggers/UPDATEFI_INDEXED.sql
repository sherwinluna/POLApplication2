/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[UPDATEFI_INDEXED]    Script Date: 02/23/2016 16:25:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Remarks:
--  Changed BEFORE INSERT to AFTER INSERT
--  Removed "FOR EACH ROW". INNER JOIN inserted is sufficient
--  Added Update FI_FILE statement
--  Renamed F00A6TC00_PROARC. to DBO.

CREATE TRIGGER [dbo].[UPDATEFI_INDEXED] 
	ON [dbo].[FI_FILE] 
	AFTER INSERT  --BEFORE INSERT
AS
BEGIN
        IF (SELECT COUNT(*) FROM inserted) > 0
	UPDATE F
	SET F.FI_INDEXED = 0, F.DOCPATH_ID = -2
	FROM dbo.FI_FILE F INNER JOIN inserted I
	ON F.FI_FILE_RNO = I.FI_FILE_RNO
END
/*
--========================================================================================================
--BASELINE (PL/SQL): 
--DROP TRIGGER F00A6TC00_PROARC.UPDATEFI_INDEXED;
--CREATE OR REPLACE TRIGGER F00A6TC00_PROARC."UPDATEFI_INDEXED" BEFORE
--INSERT ON "F00A6TC00_PROARC"."FI_FILE" FOR EACH ROW
--BEGIN
--   :NEW.FI_INDEXED := 0;
--   :NEW.DOCPATH_ID := -2;
--   EXCEPTION
--     WHEN OTHERS THEN
--       -- Consider logging the error and then re-raise
--       RAISE;
--END UpdateFi_Indexed;
--/
*/
GO


