/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00S1FP00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_TAG_CA_EQUIPTG]    Script Date: 02/23/2016 16:44:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_TAG_CA_EQUIPTG]
ON [dbo].[DX_68] 
AFTER INSERT 
AS
DECLARE
	@docrno              INTEGER,
	@docid               VARCHAR(255),
	@title               VARCHAR(255),
	@counter             INTEGER;
BEGIN
	select @docrno = Inserted.DOC_RNO from Inserted;
	
	SELECT @docid = DOC_ID  from DOCUMENT where doc_rno = @docrno;
	SELECT @title = TITLE from DOCUMENT where doc_rno = @docrno;

	SELECT @counter = COUNT(CA_EQUIPTG) FROM CALOOKUP_CA_EQUIPTG where CA_EQUIPTG = @docid;

	if @counter = 0
	begin
		INSERT INTO CALOOKUP_CA_EQUIPTG (CA_EQUIPTG, DESCRIPT, VOIDED) VALUES ( @docid, @title, 0 );
	end

END

GO


