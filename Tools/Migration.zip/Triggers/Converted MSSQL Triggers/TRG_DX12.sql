/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_DX12]    Script Date: 02/23/2016 15:31:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_DX12] ON [dbo].[DX_12] AFTER INSERT 
AS
BEGIN
DECLARE @iDb_rno  INTEGER
DECLARE @sCategory VARCHAR(45)
DECLARE @sPE_DOCTYPE  VARCHAR(65)
DECLARE @sSeq_no  VARCHAR(10)
DECLARE @iCount  INTEGER
DECLARE @sNewDocId VARCHAR(40)
DECLARE @iTest  INTEGER
DECLARE @sPrefix  VARCHAR(40)
DECLARE @iDocNo integer
	
	SELECT @iDocNo = Inserted.DOC_RNO FROM inserted
	SELECT @iDocNo = Inserted.DOC_RNO FROM inserted
	
	SELECT @sPE_DOCTYPE  = Inserted.PE_DOCTYPE from Inserted
	SELECT @iDB_rno = db_rno FROM Document where Doc_rno = @iDocNo
	
	IF @iDb_rno = 12
	
	BEGIN
	Set @sPrefix = @sPE_DOCTYPE
	END
	SELECT @sSeq_no = isNull(Seqno,0) + 1 FROM mask_seq WHERE db_rno = @iDb_rno and KEYVALUE= @sPrefix
	
	SET @sNewDocId = @sPrefix + '-'+ replicate('0', 5-len(LTRIM(RTRIM(@sSeq_no)))) + @sSeq_no
	UPDATE mask_seq SET seqno = @sSeq_no WHERE db_rno = @iDb_rno and keyvalue = @sPrefix
	
	 DECLARE @doc_rno INTEGER
	 Select  @doc_rno=Inserted.doc_rno from inserted
	 UPDATE document SET Doc_id = @sNewDocId WHERE Doc_rno =  @doc_rno
END
GO


