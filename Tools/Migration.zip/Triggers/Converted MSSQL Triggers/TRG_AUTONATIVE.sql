/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_AUTONATIVE]    Script Date: 02/23/2016 15:01:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_AUTONATIVE] ON [dbo].[DX_2] AFTER  INSERT
AS
BEGIN

DECLARE @Docrno1            INTEGER
DECLARE @Dbrno1             INTEGER
DECLARE @Docrno2            INTEGER
DECLARE @Dbrno2             INTEGER
DECLARE @Docid2             VARCHAR(60)
DECLARE @Title2              VARCHAR(255)
        
DECLARE @caproname          VARCHAR(65)
DECLARE @casprname          VARCHAR(65)
DECLARE @eddoctype          VARCHAR(45)
DECLARE @eddoccat           VARCHAR(45)
DECLARE @cacontrno          VARCHAR(50)
        
DECLARE @Created2           DATE
DECLARE @createdby2         VARCHAR(32)
DECLARE @Modifiedm2         DATE
DECLARE @Modifiedc2         DATE
DECLARE @Modifiedp2         DATE
DECLARE @Voided2             DATE
DECLARE @Flagdesc2         INTEGER
DECLARE @Packrno2           INTEGER
DECLARE @Chain2             INTEGER
DECLARE @Planhours2         FLOAT
DECLARE @Weight2            INTEGER
DECLARE @Locked2            DATE
DECLARE @Lockby2            VARCHAR(32)
DECLARE @Holds2             INTEGER
DECLARE @Revision2          VARCHAR(20)
DECLARE @Version2           VARCHAR(10)
DECLARE @Status2            VARCHAR(20)
DECLARE @Statdate2          DATE
DECLARE @Maskrno2           INTEGER
        
DECLARE @Statususerid2      VARCHAR(32)
DECLARE @Initiated2         DATE
DECLARE @Initiateduserid2   VARCHAR(32)

DECLARE @counter            INTEGER
DECLARE @sorm2 			INTEGER
DECLARE @sorm11 	INTEGER


Select @Docrno1=Inserted.doc_rno from inserted


SET @Dbrno1 = 2
SET @Dbrno2 = 11

SELECT @Docid2= ('NATIVE-' + CAST(DOC_ID AS VARCHAR(32))) from DOCUMENT WHERE DOC_RNO = @Docrno1
--SET @Docid2 = 'NATIVE-' + @Docid2

SELECT @counter= COUNT(DOC_RNO) FROM DOCUMENT WHERE DOC_ID = @Docid2 AND DB_RNO = @Dbrno2
	PRINT '<----------------------------boing AUTONATIVE boing ------------------------------>'
  PRINT 'COUNTER' + cast(@counter as varchar)
  PRINT 'DOCID:' + cast(@Docid2 as varchar)
  PRINT 'DBRNO1:' + cast(@Dbrno1 as varchar)
   PRINT 'DBRNO2:' + cast(@Dbrno2 as varchar)
  PRINT '<----------------------------boing boing ------------------------------>'
  
IF @counter = 0 
BEGIN
   UPDATE DOC_RNO SET LAST_RNO = LAST_RNO + 1
   SELECT @Docrno2 =LAST_RNO  FROM DOC_RNO

   SELECT @caproname = Inserted.CA_PRONAME FROM Inserted
   SElect @eddoctype = Inserted.ED_DOCTYPE FROM Inserted
   SELECT @eddoccat = Inserted.ED_DOCCAT FROM Inserted
   SELECT @cacontrno = Inserted.CA_CONTRNO FROM Inserted

   SELECT @sorm2 = MAX_PR_DOC   FROM DA_TYPE WHERE DB_RNO = 2 AND NAME = 'CA_SPRNAME'
   SELECT @sorm11 = MAX_PR_DOC   FROM DA_TYPE WHERE DB_RNO = 11 AND NAME = 'CA_SPRNAME'

	PRINT '<----------------------------boing AUTONATIVE boing ------------------------------>'
  PRINT 'SORm2:' + cast(@sorm2 as varchar)
  PRINT 'SORM11:' + cast(@sorm11 as varchar)
 
  PRINT '<----------------------------boing boing ------------------------------>'
  
   IF @sorm2 = 1 AND @sorm11 = 1 
	BEGIN
     SELECT @casprname = Inserted.CA_SPRNAME FROM Inserted
         INSERT INTO DX_11 ( DOC_RNO, CA_SPRNAME, CA_CONTRNO, ED_DOCTYPE, ED_DOCCAT, CA_PRONAME ) VALUES ( @Docrno2, @cacontrno, @casprname, @eddoctype, @eddoccat, @caproname )
	END
	
    IF @sorm2 > 1 AND @sorm11 > 1 
	BEGIN
        INSERT INTO DX_11 ( DOC_RNO, ED_DOCTYPE, ED_DOCCAT, CA_PRONAME, CA_CONTRNO ) VALUES ( @Docrno2, @eddoctype, @eddoccat, @caproname, @cacontrno )
        INSERT INTO DA ( DOC_RNO, DB_RNO, NAME, VALUE, DA_SORTORDER ) SELECT @Docrno2, @Dbrno2, name, value, da_sortorder FROM DA WHERE DB_RNO = 2 AND NAME = 'CA_SPRNAME' AND DOC_RNO = @Docrno1

    END 
END 

   SELECT @Title2 = TITLE  from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Created2 = CREATED   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @createdby2 = CREATED_BY   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Modifiedm2 = MODIFIED_M   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Modifiedc2 = MODIFIED_C   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Modifiedp2 = MODIFIED_P   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Voided2 = VOIDED   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Flagdesc2 =FLAG_DESC from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Packrno2 = PACK_RNO  from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Chain2 = CHAIN  from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Planhours2 = PLANHOURS  from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Weight2 = WEIGHT  from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Locked2 = LOCKED   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Lockby2 = LOCK_BY from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Holds2 = HOLDS from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Revision2 = REVISION   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Version2 = VERSION   from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Status2 = STATUS from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Statdate2 = STATDATE from DOCUMENT WHERE DOC_RNO = @Docrno1
   SELECT @Maskrno2 = MASK_RNO  from DOCUMENT WHERE DOC_RNO = @Docrno1

   INSERT INTO DOCUMENT( DOC_RNO, DB_RNO, DOC_ID, TITLE, CREATED, CREATED_BY, MODIFIED_M, MODIFIED_C, MODIFIED_P, VOIDED, FLAG_DESC, PACK_RNO, CHAIN, PLANHOURS, [WEIGHT], LOCKED, LOCK_BY, HOLDS, REVISION, [VERSION], [STATUS], REV_ID, VER_ID, STATDATE, MASK_RNO )
   VALUES ( @Docrno2, @Dbrno2, @docid2, @Title2 , @Created2, @createdby2, @Modifiedm2, @Modifiedc2, @Modifiedp2, @Voided2, @flagdesc2, @Packrno2, @Chain2, @Planhours2, @Weight2, @Locked2, @Lockby2, @Holds2, @Revision2, @Version2, @Status2, 1, 1, @Statdate2, @Maskrno2 )

   select  @Statususerid2 = USER_NAME()
   select  @Initiateduserid2 = USER_NAME()

   INSERT INTO REVISION( REV_ID, VER_ID, DOC_RNO, DB_RNO, [STATUS], STATUS_USERID, REVISION, REV_SEQNO, [VERSION], INITIATED, INITIATED_USERID, STATDATE)
   VALUES ( 1, 1, @Docrno2, @Dbrno2, @Status2, @Statususerid2, @Revision2, 1, @Version2, @Initiated2, @Initiateduserid2, @Statdate2)

   INSERT INTO DOCSTRUC ( DB_RNO, DOC_RNO, DOC_CLASS, DB_RNO2, DOC_RNO2 ) VALUES ( @Dbrno1, @Docrno1, 'REFERENCE', @Dbrno2, @Docrno2 )

If @counter = 1 
BEGIN

   SELECT @Docrno2 = DOC_RNO   FROM DOCUMENT WHERE DOC_ID = @Docid2 AND DB_RNO = @Dbrno2
   INSERT INTO DOCSTRUC ( DB_RNO, DOC_RNO, DOC_CLASS, DB_RNO2, DOC_RNO2 ) VALUES ( @Dbrno1, @Docrno1, 'REFERENCE', @Dbrno2, @Docrno2 )

END 



END
GO


