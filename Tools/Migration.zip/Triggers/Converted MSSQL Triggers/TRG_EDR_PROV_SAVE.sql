/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_EDR_PROV_SAVE]    Script Date: 02/23/2016 15:42:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_EDR_PROV_SAVE] ON [dbo].[DI_LINE] AFTER INSERT AS

BEGIN
	
	DECLARE @disrno                                   INTEGER 
	DECLARE @dbrno                                    INTEGER 
	DECLARE @dcclassrno                               INTEGER 
	DECLARE @docrno                                   INTEGER 
	DECLARE @dtype                                    INTEGER 
	DECLARE @dseqno                                   INTEGER 
	DECLARE @docrno2                                  INTEGER 
	DECLARE @distrid                                  VARCHAR(50) 
	DECLARE @title2                                   VARCHAR(255) 
	DECLARE @docid2                                   VARCHAR(60) 
	DECLARE @dbrno2                                   INTEGER 
	DECLARE @eddoccat                                 VARCHAR(50) 
	DECLARE @roffice                                  VARCHAR(20) 
	DECLARE @oorigeng                                 VARCHAR(25) 
	DECLARE @Statususerid2                            VARCHAR(32) 
	DECLARE @Initiateduserid2                         VARCHAR(32) 
	DECLARE @cacontrno                                VARCHAR(80) 
	DECLARE @caproname                                VARCHAR(80) 
	DECLARE @inistatus                                VARCHAR(20) 
	DECLARE @archivename                              VARCHAR(50) 
	DECLARE @counter                                  INTEGER 
	DECLARE @mysql                                    VARCHAR(255) 
  DECLARE @tblrno VARCHAR(20)
  DECLARE @tblwhere VARCHAR(20)

  print '<------------------------ i am prov save'
  
  
	SELECT @disrno  = inserted.DIS_RNO from inserted
	SELECT @dcclassrno  = inserted.DC_CLASS_RNO from inserted
	SELECT @dbrno  = inserted.DB_RNO from inserted
	SELECT @dtype  = inserted.TYPE from inserted
	SELECT @docrno  = inserted.DOC_RNO from inserted
	SELECT @dseqno  = inserted.SEQNO from inserted
	
	SELECT @distrid = DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno
	
	SELECT @counter = COUNT(DOC_RNO) FROM DOCUMENT WHERE DOC_ID = @distrid AND	DB_RNO = 13
	print 'dtype:' + cast(@dtype as varchar)
  print 'dcclass:' + cast(@dcclassrno as varchar)
  print 'counter:' + cast(@counter as varchar)
  print 'dseqno:' + cast(@dseqno as varchar)
  print 'disrno:' + cast(@disrno as varchar)
  print 'dbrno:' + cast(@dbrno as varchar)
  print 'docrno:' + cast(@docrno as varchar)
  print 'distrid:' + cast(@distrid as varchar)
  
	IF @counter = 0 AND @dseqno = 1 AND @dcclassrno = 1 AND @dtype = 15 
	BEGIN 
	/*
		SELECT @dbrno2  = 13 
		SELECT @inistatus  = 'SQCK' 
		SELECT @docid2 = DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno
		
		SELECT @title2 = descript FROM DISTRIB WHERE dis_rno = @disrno
		
		UPDATE  DOC_RNO SET	LAST_RNO = LAST_RNO + 1 
		
		SELECT @docrno2 = LAST_RNO FROM DOC_RNO 
		
		SELECT @Statususerid2 = SYSTEM_USER
		
		SELECT @Initiateduserid2 = SYSTEM_USER
		
		SELECT @cacontrno = CA_CONTRNO FROM CALOOKUP_CA_CONTRNO 
		
		SELECT @caproname = CA_PRONAME FROM CALOOKUP_CA_PRONAME 
		*/
		Set @dbrno2  = 13 
		Set @inistatus  = 'SQCK' 
        Set @tblrno = 'DX_' + cast(@dbrno as varchar)
        Set @tblwhere = ' WHERE DOC_RNO = ' + cast(@docrno as varchar)
				SELECT @docid2 = DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno
				
        PRINT 'docid2:' + @docid2 
				SELECT @title2  =  descript	FROM DISTRIB WHERE	dis_rno  = @disrno
        PRINT 'title2:' + @title2
				UPDATE  DOC_RNO SET	LAST_RNO = LAST_RNO + 1 
				SELECT @docrno2  = LAST_RNO	FROM DOC_RNO
        PRINT 'docrno2:' + cast(@docrno2 as varchar)
				SELECT @Statususerid2  =  SYSTEM_USER
        PRINT 'status user:'
				SELECT @Initiateduserid2  =  SYSTEM_USER
        PRINT 'init user:'
				SELECT @cacontrno  = CA_CONTRNO	FROM  CALOOKUP_CA_CONTRNO
        PRINT 'projno:'
				SELECT @caproname  = CA_PRONAME	FROM  CALOOKUP_CA_PRONAME
        
		CREATE TABLE #Temp (
			ED_DOCCAT VARCHAR(50),
			RESPOFFICE VARCHAR(20),
			ORIGENG VARCHAR(50) 
		)
		
		
		SELECT @mysql  = 'INSERT INTO #TEMP SELECT ED_DOCCAT, RESPOFFICE, ORIGENG FROM DX_' + cast(@dbrno as varchar)  + ' WHERE DOC_RNO = ' + cast(@docrno as varchar)  
		
		print @mysql
		
		EXECUTE (@mysql)
		
    SELECT @eddoccat = ED_DOCCAT from #Temp
		SELECT @roffice = RESPOFFICE from #Temp
		SELECT @oorigeng = ORIGENG from #Temp
    
		SELECT @archivename = DB_ID FROM DOCBASE WHERE DB_RNO = @dbrno
		print 'insert into dx13: ' + cast(@docrno2 as varchar)
		INSERT INTO DX_13 ( DOC_RNO, CA_PRONAME, CA_CONTRNO, ARCHIVE, ED_DOCCAT, RESPOFFICE, ORIGENG)  
		 VALUES (@docrno2, @caproname, @cacontrno, @archivename, @eddoccat, @roffice, @oorigeng)  
		
		INSERT INTO DOCUMENT (DOC_RNO, DB_RNO, DOC_ID, TITLE, CREATED, MODIFIED_M, REVISION, STATUS, REV_ID, VER_ID, STATDATE)  
		 VALUES (@docrno2, @dbrno2, @docid2, @title2, GETDATE(), GETDATE(), @inistatus, @inistatus, 1, 1, GETDATE())  
		
		INSERT INTO REVISION (REV_ID, VER_ID, DOC_RNO, DB_RNO, STATUS, STATUS_USERID, REVISION, REV_SEQNO, INITIATED, INITIATED_USERID, STATDATE)  
		 VALUES (1, 1, @docrno2, @dbrno2, @inistatus, @Statususerid2, @inistatus, 1, GETDATE(), @Initiateduserid2, GETDATE())  
		
		INSERT INTO DA (DOC_RNO, DB_RNO, NAME, VALUE, DA_SORTORDER)  
		SELECT @docrno2, @dbrno2, name, value, da_sortorder FROM DA WHERE DB_RNO = @dbrno AND NAME = 'CA_SPRNAME' AND DOC_RNO = @docrno
		
	END
END
GO


