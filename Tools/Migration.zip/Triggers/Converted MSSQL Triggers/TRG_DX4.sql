/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_DX4]    Script Date: 02/23/2016 15:33:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_DX4] ON [dbo].[DX_4] AFTER INSERT
AS
BEGIN

DECLARE @sCount VARCHAR(5)
DECLARE @iDb_rno INTEGER
DECLARE @sCategory VARCHAR(45)
DECLARE @sPO VARCHAR(65)
DECLARE @sSeq_no VARCHAR(10)
DECLARE @iCount INTEGER
DECLARE @sNewDocId VARCHAR(40)
DECLARE @iTest INTEGER
DECLARE @sPrefix VARCHAR(40)
DECLARE @iDocNo integer
DECLARE @sKeyValue VARCHAR(40)
DECLARE @iLen integer

	SELECT @sCategory = Inserted.Category FROM Inserted
	SELECT @sPO = Inserted.PO FROM Inserted
	SELECT @iDocNo = Inserted.DOC_RNO FROM inserted
	
	----SELECT @iDb_rno = db_rno, @sPO = Inserted.PO FROM Inserted
	
    SELECT @iDB_rno = db_rno FROM dbo.Document where Doc_rno = @iDocNo
    SELECT @sKeyvalue = keyvalue FROM dbo.mask_seq where keyvalue = @sKeyValue
    
	
  IF @iDb_rno = 4
	BEGIN
	 If @sCategory = 'REQUIREMENT'
	  BEGIN
	   SET @sPrefix = 'REQMT-' + @sPO
	  END
	 else
	  BEGIN
	   SET @sPrefix = @sPO
	  END
	  
	  SELECT @iCount = MAX(seqno) FROM dbo.mask_seq WHERE db_rno = @iDb_rno and KEYVALUE= @sPrefix
	  If @iCount IS NULL
	  Begin
		INSERT INTO mask_seq (Db_rno, mask_rno, Keyvalue, Seqno) VALUES (@iDb_rno,-1,@sPrefix,0)
		SET @iCount = 0
	  End
	  
	  SET @iCount = @iCount + 1
	  SET @sCount = CAST(@iCount as VARCHAR(5))
	  SET @iLen = LEN (LTRIM(RTRIM(@sCount)))
	  SET @sNewDocid = @sPrefix + '-' + LEFT (REPLICATE('0',5 - @iLen)+LTRIM(RTRIM(cast(@iCount as varchar(5)))),5)
	  
	 
	  
	  UPDATE mask_seq SET seqno = @iCount WHERE db_rno = @iDb_rno and keyvalue = @sPrefix
	  --INSERT INTO mask_seq (Db_rno, mask_rno, Keyvalue, Seqno) VALUES (@iDb_rno,-1,@sNewDocId,0)
	  UPDATE document SET Doc_id = @sNewDocId WHERE Doc_rno = @iDocNo
	  
	END
END
GO


