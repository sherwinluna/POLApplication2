create function [dbo].[isnull2](@string1 varchar(500), @string2 varchar(500), @string3 varchar(500))
returns varchar(50)
with execute as caller
as
begin
	declare @ret varchar(50);
	if (LTRIM(RTRIM(isnull(@string1,''))) <> '')
	begin 
		set @ret = @string2;	
	end
	else
	begin
		set @ret = @string3;
	end
		
	return @ret
end
GO
