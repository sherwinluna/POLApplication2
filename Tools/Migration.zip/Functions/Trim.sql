create function [dbo].[Trim](@string varchar(500))
returns varchar(50)
with execute as caller
as
begin
	return ltrim(rtrim(@string));		
end

GO


