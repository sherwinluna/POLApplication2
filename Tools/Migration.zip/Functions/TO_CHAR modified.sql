USE [F00007425_DMS]
GO

/****** Object:  UserDefinedFunction [dbo].[TO_CHAR]    Script Date: 03/14/2017 16:14:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE function [dbo].[TO_CHAR](@date datetime, @format varchar(50))
returns varchar(50)
with execute as caller
as
begin
	declare @ret varchar(50);
	
	if upper(@format) = upper('DD-Mon-YYYY')
	begin
		set @ret = CONVERT(VARCHAR(11),@date,106);
	end
	else if upper(@format) = upper('YY')
	begin
		set @ret = RIGHT(CONVERT(VARCHAR(4), @date, 112),2);
	end
	else if UPPER(@format) = UPPER('DD-MON-YY')
	begin
		set @ret = CONVERT(VARCHAR(11),@date,106);
	end
	else
	begin
		set @ret = CONVERT(VARCHAR(11),@date,106);
	end
	
	return @ret;		
end


GO


