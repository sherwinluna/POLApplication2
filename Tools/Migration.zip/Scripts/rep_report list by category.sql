select (select top 1 DB_ID from db_grp where db_rno = rep_report.dic_segment), rep_report, dic_class, rep_title, rep_filename 
from rep_report 
order by dic_class, rep_report, dic_segment