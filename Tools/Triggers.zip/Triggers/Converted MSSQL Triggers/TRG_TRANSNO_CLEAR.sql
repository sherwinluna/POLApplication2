/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_TRANSNO_CLEAR]    Script Date: 02/23/2016 16:22:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Remarks:
--  Added CURSOR (for each row)
--  Renamed F00A6TC00_PROARC. to DBO.

CREATE TRIGGER [dbo].[TRG_TRANSNO_CLEAR] 
	ON [dbo].[REVISION] AFTER INSERT --AFTER INSERT 
AS
BEGIN--(1)

	

		DECLARE @DOC_RNO INTEGER
		DECLARE @DB_RNO INTEGER
		DECLARE @docexist INTEGER 
		
		SELECT @DOC_RNO = Inserted.DOC_RNO FROM Inserted
		SELECT @DB_RNO = Inserted.DB_RNO FROM Inserted
		
/*=============================================
	-- Remarks: Commented by Cathy
	OPEN FOR_EACH_ROW_CURSOR 
		FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO @DOC_RNO, @DB_RNO
	WHILE (@@FETCH_STATUS <> -1)
	BEGIN--(2)

==============================================*/




		SELECT @docexist  =  COUNT(DOC_RNO)
		FROM  DOCUMENT 
		WHERE	 DOC_RNO  = @DOC_RNO
		
		IF @docexist = 1 AND @DB_RNO = 2 
		BEGIN 
			UPDATE DX_2 SET transno = '' 
			WHERE  DOC_RNO  = @DOC_RNO 
			
			UPDATE DX_2 SET	transdate = null 
			WHERE  DOC_RNO  = @DOC_RNO 
		END
	   
		IF @docexist = 1 AND @DB_RNO = 4 
		BEGIN 
			UPDATE DX_4 SET	transno = '' 
			WHERE  DOC_RNO  = @DOC_RNO 
			
			UPDATE DX_4 SET	transdate = null 
			WHERE  DOC_RNO  = @DOC_RNO 
			
			UPDATE DX_4 SET	SUP_FD = '' 
			WHERE  DOC_RNO  = @DOC_RNO 
			
			UPDATE DX_4 SET	RESUBDATE = '' 
			WHERE  DOC_RNO  = @DOC_RNO 
		END

/*=============================

	FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO @DOC_RNO, @DB_RNO
	END--(2)

	CLOSE FOR_EACH_ROW_CURSOR
	DEALLOCATE FOR_EACH_ROW_CURSOR
=============================*/
END--(1)


--########################################################################################################
--BASELINE (PL/SQL): 
--DROP TRIGGER F00A6TC00_PROARC.TRG_TRANSNO_CLEAR;
--CREATE OR REPLACE TRIGGER F00A6TC00_PROARC."TRG_TRANSNO_CLEAR" AFTER INSERT ON "F00A6TC00_PROARC".REVISION
--FOR EACH ROW
--DECLARE

--dbrno              INTEGER;
--docrno            INTEGER;

--docexist         INTEGER;

--BEGIN

--SELECT COUNT( DOC_RNO ) INTO docexist FROM DOCUMENT WHERE DOC_RNO = :New.DOC_RNO;

--IF docexist = 1 AND :New.DB_RNO = 2 THEN
--   UPDATE DX_2 SET transno = '' WHERE DOC_RNO = :New.DOC_RNO;
--   UPDATE DX_2 SET transdate = '' WHERE DOC_RNO = :New.DOC_RNO;
--END IF;

--IF docexist = 1 AND :New.DB_RNO = 4 THEN
--   UPDATE DX_4 SET transno = '' WHERE DOC_RNO = :New.DOC_RNO;
--   UPDATE DX_4 SET transdate  = '' WHERE DOC_RNO = :New.DOC_RNO;
--   UPDATE DX_4 SET SUP_FD = '' WHERE DOC_RNO = :NEW.DOC_RNO;
--END IF;

--IF docexist = 1 AND :New.DB_RNO = 4  THEN
--   UPDATE DX_4 SET RESUBDATE = '' WHERE DOC_RNO = :New.DOC_RNO;

--END IF;

--END;
--/
GO


