/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_TAG_UPDATE]    Script Date: 02/23/2016 16:42:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_TAG_UPDATE] 
ON [dbo].[DOCUMENT] 
AFTER UPDATE 
AS
DECLARE
	@dbrno               INTEGER,              
	@docrno              INTEGER,
	@olddocid            VARCHAR(255),
	@newdocid            VARCHAR(255),
	@newtitle            VARCHAR(255),
	@counter             INTEGER;
BEGIN
	select @dbrno = Inserted.DB_RNO from Inserted;
	select @olddocid = Deleted.DOC_ID from Deleted;
	select @newdocid = Inserted.DOC_ID from Inserted;
	select @newtitle = Inserted.TITLE from Inserted;

	if @dbrno = 68 
	begin

		if @olddocid = @newdocid 
		begin
			UPDATE CALOOKUP_CA_EQUIPTG set DESCRIPT = @newtitle where CA_EQUIPTG = @olddocid;
	    end
		else
	    begin
			SELECT @counter = COUNT(CA_EQUIPTG) FROM CALOOKUP_CA_EQUIPTG where CA_EQUIPTG = @newdocid;

			if @counter = 0 
			begin
			   UPDATE CALOOKUP_CA_EQUIPTG set CA_EQUIPTG = @newdocid where CA_EQUIPTG = @olddocid;
			   UPDATE CALOOKUP_CA_EQUIPTG set DESCRIPT = @newtitle where CA_EQUIPTG = @newdocid;
			end
		end
	end
END

GO


