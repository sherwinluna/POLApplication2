/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_TRANS_CONSOL]    Script Date: 02/23/2016 16:14:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_TRANS_CONSOL] ON [dbo].[DI_REC] AFTER UPDATE AS
BEGIN
	IF (UPDATE (ACT_CLOSED))
	BEGIN
   PRINT '<-------  UPDATE - CONSOLIDATED' 
		DECLARE @disrno                                   INTEGER 
		DECLARE @actid                                    INTEGER 
		DECLARE @dbrno                                    INTEGER 
		DECLARE @docrno                                   INTEGER 
		DECLARE @actclosed                                DATETIME 
		DECLARE @dcclassrno                               INTEGER 
		DECLARE @acttype                                  INTEGER 
		DECLARE @actname                                  VARCHAR(25) 
		DECLARE @drcondcode                               VARCHAR(20) 
		DECLARE @docrno2                                  INTEGER 
		DECLARE @distrid                                  VARCHAR(50) 
		DECLARE @title2                                   VARCHAR(255) 
		DECLARE @docid2                                   VARCHAR(60) 
		DECLARE @dbrno2                                   INTEGER 
		DECLARE @prefixid                                 VARCHAR(50) 
		DECLARE @prarchive                                VARCHAR(22) 
		DECLARE @prdateissued                             DATETIME 
		DECLARE @roffice                                  VARCHAR(20) 
		DECLARE @Statususerid2                            VARCHAR(32) 
		DECLARE @Initiateduserid2                         VARCHAR(32) 
		DECLARE @cacontrno                                VARCHAR(80) 
		DECLARE @caproname                                VARCHAR(80) 
		DECLARE @inirev                                   VARCHAR(20) 
		DECLARE @inistat                                  VARCHAR(20) 
		DECLARE @counter                                  INTEGER 
		DECLARE @daexist                                  INTEGER 
		DECLARE @mysql                                    VARCHAR(255) 
		SELECT @Disrno = deleted.dis_rno from deleted
		SELECT @actid = deleted.act_id from deleted
		SELECT @dcclassrno = deleted.dc_class_rno from deleted
		SELECT @acttype = deleted.type from deleted
		SELECT @drcondcode = inserted.DR_COND_CODE from inserted
		SELECT @counter = COUNT(DOC_RNO) FROM DOCUMENT WHERE DOC_ID = (SELECT DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno) AND DB_RNO  = 10
		
		IF @counter = 0 
		BEGIN 
			SELECT @actname  =  act_name FROM DI_ACT WHERE act_id = @actid AND type = @acttype AND dc_class_rno = @dcclassrno
			
			SELECT @prefixid = PREFIX_ID FROM DI_TYPE WHERE TYPE = @acttype
      PRINT '<------- INSIDE IF counter CONSOLIDATED' 
      print '<------- dcclassrno - ' + cast(@dcclassrno as varchar)
      print '<------- actname - ' + @actname
			
			IF @dcclassrno = 7 AND @actname = 'QA' 
	
			BEGIN 
				SELECT @dbrno = DB_RNO FROM DI_LINE WHERE DIS_RNO = @disrno AND	SEQNO = 1
				
				SELECT @dbrno2  = 10 
				SELECT @inirev  = 'ISSUED'
				
				SELECT @docid2 = DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno
				
				SELECT @title2 = descript FROM DISTRIB WHERE dis_rno = @disrno
				
				SELECT @prdateissued = SENT FROM DISTRIB WHERE dis_rno = @disrno
				
				UPDATE DOC_RNO SET	LAST_RNO = LAST_RNO + 1 
				
				SELECT @docrno2 = LAST_RNO FROM DOC_RNO 
				
				SELECT @Statususerid2 = SYSTEM_USER
				
				SELECT @Initiateduserid2 = SYSTEM_USER
				
				SELECT @cacontrno = CA_CONTRNO FROM CALOOKUP_CA_CONTRNO
				
				SELECT @caproname = CA_PRONAME FROM CALOOKUP_CA_PRONAME 
				
				SELECT @prarchive = DB_ID FROM DOCBASE WHERE DB_RNO = @dbrno
				
				CREATE TABLE #Temp (
					RESPOFFICE VARCHAR(20)
				)
				
				SELECT @mysql  = 'INSERT INTO #TEMP SELECT RESPOFFICE FROM DX_' + cast(@dbrno as varchar)  +' WHERE DOC_RNO = ( SELECT DOC_RNO FROM DI_LINE WHERE DIS_RNO =' + cast(@Disrno as varchar)  +' AND DB_RNO =' + cast(@dbrno as varchar)  +' AND SEQNO = 1 )' 
				
				print @mysql
				
				EXECUTE (@mysql)
				
				SELECT @inistat = STATUS FROM DOCUMENT WHERE DOC_RNO = (SELECT DOC_RNO FROM DI_LINE WHERE DIS_RNO = @disrno AND	SEQNO  = 1)
				
				INSERT INTO DX_10 (DOC_RNO, CA_PRONAME, CA_CONTRNO, PR_ARCHIVE, PR_DATE_ISSUED, RESPOFFICE)  
				 VALUES (@docrno2, @caproname, @cacontrno, @prarchive, @prdateissued, @roffice)  
				
				INSERT INTO DOCUMENT (DOC_RNO, DB_RNO, DOC_ID, TITLE, CREATED, CREATED_BY, REVISION, STATUS, REV_ID, VER_ID, STATDATE)  
				 VALUES (@docrno2, @dbrno2, @docid2, @title2, GETDATE(), @Statususerid2, @inirev, @inistat, 1, 1, GETDATE())  
				
				INSERT INTO REVISION (REV_ID, VER_ID, DOC_RNO, DB_RNO, STATUS, STATUS_USERID, REVISION, REV_SEQNO, INITIATED, INITIATED_USERID, STATDATE)  
				 VALUES (1, 1, @docrno2, @dbrno2, @inistat, @Statususerid2, @inirev, 1, GETDATE(), @Initiateduserid2, GETDATE())  
				
					
		
				
			END
   
		END
		ELSE
		BEGIN 
			IF @counter = 1 
			BEGIN 
				SELECT @docrno2  =  DOC_RNO FROM DOCUMENT WHERE DOC_ID = (SELECT DISTR_ID FROM DISTRIB WHERE DIS_RNO = @disrno) AND	DB_RNO  = 10
				
				SELECT @title2 = descript FROM DISTRIB WHERE dis_rno = @disrno
				
				SELECT @prdateissued = SENT FROM DISTRIB WHERE dis_rno = @disrno
				
				UPDATE DX_10 SET PR_DATE_ISSUED = @prdateissued WHERE DOC_RNO = @docrno2 
				
				UPDATE DOCUMENT SET	TITLE = @title2 WHERE DOC_RNO = @docrno2
			END
   
		END
	END
END
GO


