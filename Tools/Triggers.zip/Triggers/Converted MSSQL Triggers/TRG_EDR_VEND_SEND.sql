/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_EDR_VEND_SEND]    Script Date: 02/23/2016 15:46:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[TRG_EDR_VEND_SEND] ON [dbo].[DISTRIB] AFTER UPDATE AS

BEGIN
	IF (UPDATE (SENT))
	BEGIN
		
		DECLARE @disrno                                   INTEGER 
		DECLARE @dbrno                                    INTEGER 
		DECLARE @dcclassrno                               INTEGER 
		DECLARE @docrno                                   INTEGER 
		DECLARE @dtype                                    INTEGER 
		DECLARE @distrid                                  VARCHAR(50) 
		DECLARE @ddescript                                VARCHAR(255) 
		DECLARE @ddiscipline                              VARCHAR(50) 
		DECLARE @roffice                                  VARCHAR(20) 
		DECLARE @ppo                                      VARCHAR(50) 
		DECLARE @companyid                                VARCHAR(65) 
		DECLARE @edesc                                    VARCHAR(255) 
		DECLARE @oorigeng                                 VARCHAR(40) 
		DECLARE @counter                                  INTEGER 
		DECLARE @mysql                                    VARCHAR(255) 
		
		SELECT @disrno  = inserted.DIS_RNO FROM inserted
		SELECT @dcclassrno = inserted.DC_CLASS_RNO FROM inserted
		SELECT @dtype  = inserted.Type FROM inserted
		SELECT @ddescript  = inserted.DESCRIPT FROM inserted
		SELECT @distrid  = inserted.DISTR_ID FROM inserted

		SELECT @counter = COUNT(DOC_RNO) FROM  DOCUMENT WHERE DOC_ID = @distrid AND	DB_RNO = 13
		print '<------------- i am vend send'
    print '<------------->Counter:' + cast(@counter as varchar)
    print '<------------->dcclassrno:' + cast(@dcclassrno as varchar)
    print '<------------->dtype:' + cast(@dtype as varchar)
     print '<------------->dtype:' + cast(@distrid as varchar)
    
		IF @counter = 0 AND @dcclassrno =6 AND @dtype = 14 
		BEGIN 
			SELECT @dbrno = DB_RNO FROM DI_LINE WHERE DIS_RNO = @disrno AND	SEQNO = 1
			
			CREATE TABLE #Temp (
				DISCIPLINE VARCHAR(50),
				RESPOFFICE VARCHAR(20),
				PO VARCHAR(50) 
			)
			
			SELECT @mysql  = 'INSERT INTO #TEMP SELECT DISCIPLINE, RESPOFFICE, PO FROM DX_' + cast(@dbrno as varchar)  +' WHERE DOC_RNO = ( SELECT DOC_RNO FROM DI_LINE WHERE DIS_RNO =' + cast(@disrno as varchar)  +' AND DB_RNO =' + cast(@dbrno as varchar)  +' AND TYPE =' + cast(@dtype as varchar)  +' AND SEQNO = 1 )' 
			
			print @mysql			

			execute(@mysql)
			
			SELECT @ddiscipline = DISCIPLINE from #Temp
			SELECT @roffice = RESPOFFICE from #Temp
			SELECT @ppo = PO from #Temp

			SELECT @edesc = TITLE FROM DOCUMENT WHERE DOC_ID = @ppo AND	DB_RNO = 3
			
			SELECT @oorigeng = EXPEDITOR FROM  DX_3 WHERE DOC_RNO  = (SELECT DOC_RNO FROM DOCUMENT WHERE DOC_ID = @ppo AND DB_RNO = 3)
			
			SELECT @companyid = COMPANYTXT FROM  DX_3  WHERE DOC_RNO = (SELECT DOC_RNO FROM DOCUMENT WHERE DOC_ID = @ppo AND DB_RNO  = 3)
			
			UPDATE  DOCUMENT SET TITLE = @ddescript WHERE DB_RNO = 13 AND DOC_ID = @distrid 
			
			UPDATE  DX_13 SET DISCIPLINE = @ddiscipline WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid) 
			
			UPDATE  DX_13 SET RESPOFFICE = @roffice WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid) 
			
			UPDATE  DX_13 SET PO = @ppo WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid)  
			
			UPDATE  DX_13 SET SUP_NAME = @companyid WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid) 
			
			UPDATE  DX_13 SET EQUIP_DESC = @edesc WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid) 
			
			UPDATE  DX_13 SET ORIGENG = @oorigeng WHERE DOC_RNO =(SELECT DOC_RNO FROM DOCUMENT WHERE DB_RNO  = 13 AND	DOC_ID = @distrid) 
			
		END
   	END
END
GO


