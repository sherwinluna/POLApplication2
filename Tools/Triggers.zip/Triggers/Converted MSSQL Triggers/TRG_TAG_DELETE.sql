/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_TAG_DELETE]    Script Date: 02/23/2016 16:41:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_TAG_DELETE]
ON [dbo].[DOCUMENT]
INSTEAD OF DELETE  
AS
DECLARE
	@docrno              INTEGER,
	@docid               VARCHAR(255),
	@title               VARCHAR(255),
	@counter             INTEGER;
BEGIN
	select @docrno = Deleted.DOC_RNO from Deleted;
	select @docid = Deleted.DOC_ID from Deleted;

	declare @dbrno integer;
	select @dbrno = Deleted.db_rno from Deleted;
	
	if @dbrno = 68  
	begin
		SELECT @counter = COUNT(CA_EQUIPTG) FROM CALOOKUP_CA_EQUIPTG where CA_EQUIPTG = @docid;
		if @counter = 1 
		begin
			DELETE FROM CALOOKUP_CA_EQUIPTG WHERE CA_EQUIPTG = @docid;
		end
	end  
END

GO


