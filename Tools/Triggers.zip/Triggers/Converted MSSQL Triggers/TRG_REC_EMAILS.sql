/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_REC_EMAILS]    Script Date: 02/23/2016 16:11:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Remarks:
--  Added CURSOR (for each row)
--  Added Update REC statement
--  Renamed F00A6TC00_PROARC. to DBO.

CREATE TRIGGER [dbo].[TRG_REC_EMAILS] 
	ON [dbo].[REC] INSTEAD OF INSERT --BEFORE INSERT
AS
BEGIN--(1)

	DECLARE @REC_ID       VARCHAR(32)
	DECLARE @INIT         VARCHAR(10)
	DECLARE @NAME         VARCHAR(50)
	DECLARE @REC_TYPE     INTEGER
	DECLARE @VOIDED       DATETIME
	DECLARE @CATEGORY     VARCHAR(10)
	DECLARE @EMAIL_ID     VARCHAR(255)
	DECLARE @EMAIL_APP    VARCHAR(32)
	DECLARE @EMAIL_NODE   VARCHAR(32)
	DECLARE @COMPANY_ID   VARCHAR(20)
	DECLARE @DEPT_ID      VARCHAR(20)
	DECLARE @LOC_ID       VARCHAR(20)
	DECLARE @ACCESS_TYP   INTEGER
	DECLARE @USE_A_ADR    INTEGER
	DECLARE @USE_A_MAIL   INTEGER
	DECLARE @ADDRESS1     VARCHAR(80)
	DECLARE @ADDRESS2     VARCHAR(80)
	DECLARE @ZIPCODE      VARCHAR(20)
	DECLARE @CITY         VARCHAR(80)
	DECLARE @COUNTRY      VARCHAR(80)
	DECLARE @STREET       VARCHAR(80)
	DECLARE @FROMDATE     DATETIME
	DECLARE @TODATE       DATETIME
	DECLARE @TLF          VARCHAR(20)
	DECLARE @FAX          VARCHAR(20)
	DECLARE @TELEX        VARCHAR(20)
	DECLARE @MODIFIED_BY  VARCHAR(32)

	
	SELECT @REC_ID = Inserted.REC_ID from Inserted
	SELECT @INIT = Inserted.INIT from Inserted
	SELECT @NAME = Inserted.NAME from Inserted
	SELECT @VOIDED = Inserted.VOIDED from Inserted
	SELECT @CATEGORY = Inserted.CATEGORY from Inserted
	SELECT @EMAIL_ID = Inserted.EMAIL_ID from Inserted
	SELECT @EMAIL_APP = Inserted.EMAIL_APP from Inserted
	SELECT @EMAIL_NODE = Inserted.EMAIL_NODE from Inserted
	SELECT @COMPANY_ID = Inserted.COMPANY_ID from Inserted
	SELECT @DEPT_ID = Inserted.DEPT_ID from Inserted
	SELECT @LOC_ID = Inserted.LOC_ID from Inserted
	SELECT @ACCESS_TYP = Inserted.ACCESS_TYP from Inserted
	SELECT @USE_A_ADR = Inserted.USE_A_ADR from Inserted
	SELECT @USE_A_MAIL = Inserted.USE_A_MAIL from Inserted
	SELECT @ADDRESS1 = Inserted.ADDRESS1 from Inserted
	SELECT @ADDRESS2 = Inserted.ADDRESS2 from Inserted
	SELECT @ZIPCODE = Inserted.ZIPCODE from Inserted
	SELECT @CITY = Inserted.CITY from Inserted
	SELECT @COUNTRY = Inserted.COUNTRY from Inserted
	SELECT @STREET = Inserted.STREET from Inserted
	SELECT @FROMDATE = Inserted.FROMDATE from Inserted
	SELECT @TODATE = Inserted.TODATE from Inserted
	SELECT @TLF = Inserted.TLF from Inserted
	SELECT @FAX = Inserted.FAX from Inserted
	SELECT @TELEX = Inserted.TELEX from Inserted
	SELECT @MODIFIED_BY = Inserted.MODIFIED_BY from Inserted
	
	

		DECLARE @sCount INTEGER 
		SELECT @sCount = COUNT(REC_ID) FROM dbo.REC WHERE REC_ID = @REC_ID

	    IF (SELECT COUNT(*) FROM inserted) > 0 AND (SELECT COUNT(*) FROM deleted) = 0
		BEGIN
			INSERT INTO dbo.REC (
				  REC_ID,
				  INIT,
				  NAME,
				  REC_TYPE,
				  VOIDED,
				  CATEGORY,
				  EMAIL_ID,
				  EMAIL_APP,
				  EMAIL_NODE,
				  COMPANY_ID,
				  DEPT_ID,
				  LOC_ID,
				  ACCESS_TYP,
				  USE_A_ADR,
				  USE_A_MAIL,
				  ADDRESS1,
				  ADDRESS2,
				  ZIPCODE,
				  CITY,
				  COUNTRY,
				  STREET,
				  FROMDATE,
				  TODATE,
				  TLF,
				  FAX,
				  TELEX,
				  MODIFIED_BY)
			  VALUES ( @REC_ID
					, @INIT
					, @NAME
					, @REC_TYPE
					, @VOIDED
					, @CATEGORY
					, @EMAIL_ID
					, @EMAIL_APP
					, @EMAIL_NODE
					, @COMPANY_ID
					, @DEPT_ID
					, @LOC_ID
					, @ACCESS_TYP
					, @USE_A_ADR
					, @USE_A_MAIL
					, @ADDRESS1
					, @ADDRESS2
					, @ZIPCODE
					, @CITY
					, @COUNTRY
					, @STREET
					, @FROMDATE
					, @TODATE
					, @TLF
					, @FAX
					, @TELEX
					, @MODIFIED_BY )
			
			IF @sCount = 0 --First time new user
			BEGIN 
				UPDATE R
					SET R.USE_A_MAIL = 1
					FROM dbo.REC R INNER JOIN inserted I 
					ON R.REC_ID = I.REC_ID
					WHERE R.TODATE IS NULL
					AND R.REC_ID = @REC_ID
			END
		END
	
END--(1)

/*
--########################################################################################################
--BASELINE (PL/SQL): 
--DROP TRIGGER F00A6TC00_PROARC.TRG_REC_EMAILS;
--CREATE OR REPLACE TRIGGER F00A6TC00_PROARC."TRG_REC_EMAILS" BEFORE
--INSERT ON "F00A6TC00_PROARC".REC FOR EACH ROW
--DECLARE
--sCount INTEGER;
--sUser VARCHAR(50);

--BEGIN

--sUser:=:New.REC_ID;

--select COUNT(REC_ID) into sCount from REC where REC_ID = sUser;

--if sCount = 0 then
--   :NEW.USE_A_MAIL := 1;
--end if;

--   EXCEPTION
--     WHEN OTHERS THEN
--       -- Consider logging the error and then re-raise
--       RAISE;
--END;
--/
*/
GO


