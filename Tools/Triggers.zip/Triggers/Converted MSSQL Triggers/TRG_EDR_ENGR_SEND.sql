/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

CREATE TRIGGER [dbo].[TRG_EDR_ENGR_SEND] ON [dbo].[DISTRIB] AFTER UPDATE

AS
BEGIN
	IF (UPDATE (SENT))
	BEGIN
		
		
		DECLARE @disrno INTEGER 
		DECLARE @dbrno INTEGER 
		DECLARE @dcclassrno INTEGER 
		DECLARE @docrno INTEGER 
		DECLARE @dtype INTEGER 
		DECLARE @distrid VARCHAR(50) 
		DECLARE @ddescript VARCHAR(255) 
		DECLARE @eddoccat VARCHAR(50) 
		DECLARE @roffice VARCHAR(20) 
		DECLARE @oorigeng VARCHAR(25) 
		DECLARE @counter INTEGER 
		DECLARE @mysql VARCHAR(255) 
		
		
		SELECT @ddescript = Inserted.DESCRIPT FROM INSERTED
		SELECT @disrno  = Inserted.DIS_RNO FROM Inserted
		SELECT @dcclassrno  = Inserted.DC_CLASS_RNO FROM Inserted
		SELECT @dtype  = Inserted.TYPE FROM Inserted
		SELECT @distrid  = Inserted.DISTR_ID FROM Inserted
		SELECT @counter  =  COUNT(DOC_RNO) FROM  DOCUMENT WHERE	 DOC_ID  = @distrid AND	DB_RNO  = 13
		
		IF @counter = 1 AND @dcclassrno = 2 AND @dtype = 13 
		BEGIN 
			
			SELECT @dbrno  =  DB_RNO FROM  DI_LINE WHERE DIS_RNO  = @disrno AND	SEQNO  = 1

      CREATE TABLE #Temp (
				ED_DOCCAT VARCHAR(50),
				RESPOFFICE VARCHAR(20),
				ORIGENG VARCHAR(50) 
			)
			
        
        
			SELECT @mysql  = 'INSERT INTO #TEMP SELECT ED_DOCCAT, RESPOFFICE, ORIGENG FROM DX_' + cast(@dbrno as varchar)  +' WHERE DOC_RNO = ( SELECT DOC_RNO FROM DI_LINE WHERE DIS_RNO =' + cast(@disrno as varchar)  +' AND DB_RNO =' + cast(@dbrno as varchar)  +' AND TYPE =' + cast(@dtype as varchar)  +' AND SEQNO = 1 )' 
			
      print @mysql
      
      EXECUTE (@mysql)	
			
      SELECT @eddoccat = ED_DOCCAT from #Temp
			SELECT @roffice = RESPOFFICE from #Temp
			SELECT @oorigeng = ORIGENG from #Temp



			UPDATE  DOCUMENT SET	TITLE = isnull(@ddescript,'') WHERE  DB_RNO  = 13 AND	DOC_ID  = @distrid 
			
			UPDATE  DX_13 SET	ED_DOCCAT = @eddoccat WHERE  DOC_RNO  =(SELECT DOC_RNO FROM DOCUMENT WHERE	 DB_RNO  = 13 AND	DOC_ID  = @distrid) 
			
			UPDATE  DX_13 SET	RESPOFFICE = @roffice WHERE  DOC_RNO  =(SELECT DOC_RNO FROM  DOCUMENT WHERE	 DB_RNO  = 13 AND	DOC_ID  = @distrid) 
			
			UPDATE  DX_13  SET	ORIGENG = @oorigeng WHERE  DOC_RNO  =(SELECT DOC_RNO FROM  DOCUMENT WHERE	 DB_RNO  = 13 AND DOC_ID  = @distrid) 
			
		END
   
		
		
	END
END

GO


