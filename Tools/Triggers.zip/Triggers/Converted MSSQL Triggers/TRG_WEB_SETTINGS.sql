/*Uncomment and change or rename the use line to the name of the database where this script will be executed */
--USE [F00W7DC00_DMS]
GO

/****** Object:  Trigger [dbo].[TRG_WEB_SETTINGS]    Script Date: 02/23/2016 16:23:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Based on TRIGGER F00T2LA00_PROARC.TRG_WEB_SETTINGS 
CREATE TRIGGER  [dbo].[TRG_WEB_SETTINGS]
	ON [dbo].[USERS] AFTER INSERT 
AS
BEGIN

	DECLARE FOR_EACH_ROW_CURSOR CURSOR LOCAL FOR 
	SELECT USER_ID
	FROM  inserted 

	OPEN FOR_EACH_ROW_CURSOR 

	DECLARE @UserID VARCHAR(32)
	DECLARE @VAR_SCHEMA VARCHAR(25) 
	DECLARE @VAR_INSTANCE VARCHAR(20) 
	SELECT @VAR_SCHEMA  = 'F00W7DC00_DMS' 
	SELECT @VAR_INSTANCE  = 'dbo' 

	FETCH NEXT FROM FOR_EACH_ROW_CURSOR INTO @UserID;

	WHILE (@@FETCH_STATUS <> -1)
	BEGIN

	IF (LEN(@UserID)= 8 and 0 = (select count(*) from DBO.US_USER_SETTINGS us where (@UserID) = us.USER_ID))
	BEGIN 
		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WEB' , 
				'FILECOPYOPTION' , 
				'-1' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WEB' , 
				'INCLUDE_VOIDED' , 
				'False' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WEB' , 
				'LANGUAGE' , 
				'2' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WEB' , 
				'SPLIT_SCREENS' , 
				'False' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WEB' , 
				'SPLIT_SCREEN_SIZE' , 
				NULL )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'FILEIMPORT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) , 
				'IMPORTFILECREATEPREVIEW' , 
				'0' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'WORKFLOW_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) , 
				'SAVECONTENTFILESDEFAULT' , 
				'FALSE' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_CONTMGMT' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_CONTMGMT' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_EDR' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_EDR' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_ENGRDOCS' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_ENGRDOCS' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_MATLMGMT' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_MATLMGMT' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_NATIVE' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_NATIVE' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_POGLOBAL' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_POGLOBAL' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_PROJEXEC' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_PROJEXEC' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_PROVINFO' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_PROVINFO' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_TRANS' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_TRANS' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_VENDDATA' , 
				'NEWDOCUMENTCOPYFILES' , 
				'NO' )  

		INSERT INTO  US_USER_SETTINGS   
				( DB_RNO , 
				USER_ID , 
				US_SECTION , 
				US_KEY , 
				US_PARAMETER )  
		 VALUES 		(-1 , 
				@UserID , 
				'DOCUMENT_ ' + CAST(@VAR_SCHEMA AS VARCHAR) + '_ ' + CAST(@VAR_INSTANCE AS VARCHAR) + '_VENDDATA' , 
				'REVISIONREVISEFILES' , 
				'NO' )  

	END

		FETCH Next FROM FOR_EACH_ROW_CURSOR INTO @UserID
	END

	CLOSE FOR_EACH_ROW_CURSOR
	DEALLOCATE FOR_EACH_ROW_CURSOR
END
GO


